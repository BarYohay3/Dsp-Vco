/*
 * P2 - VCO Filtering Project
 * DSP Course - Braude College
 *
 * CORRECTED VERSION - Using Sample Counter for 12-second toggle (Clock Module replacement for stability) for 12-second toggle
 */

/*  ----------------------------------- XDC module Headers           */
#include <xdc/std.h>
#include <xdc/runtime/Timestamp.h>
#include <xdc/runtime/Types.h>
#include <xdc/runtime/Diags.h>

/*  ----------------------------------- BIOS module Headers           */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Swi.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <xdc/cfg/global.h>

/*  ----------------------------------- Math Header           */
#include <math.h>

/* ============================= Constants ============================= */
#define PI              3.14159265358979f
#define FS              12500.0f        // Sampling frequency 12.5KHz
#define TS              (1.0f/FS)       // Sampling period 80us
#define K_VCO           5000.0f         // VCO constant k
#define V_MIN           0.1f            // Minimum sawtooth amplitude
#define V_MAX           1.0f            // Maximum sawtooth amplitude
#define BUFFER_SIZE     2000            // Display buffer size
#define FIR_TAPS        64              // FIR filter taps

/* ============================= Global Variables ============================= */

/* Input/Output Buffers for display */
float inputBuffer[BUFFER_SIZE];
float outputBuffer[BUFFER_SIZE];
volatile UInt16 bufferIndex = 0;

/* VCO Phase accumulator */
volatile float vcoPhase = 0.0f;

/* Sawtooth generator */
volatile float sawtoothValue = V_MIN;

/* Filter selection: 0 = FIR, 1 = IIR */
volatile UInt8 filterSelect = 0;

/* Sweep time selection: 0 = 3s, 1 = 6s */
volatile UInt8 sweepTimeSelect = 0;

/* Current input and output samples */
volatile float currentInput = 0.0f;
volatile float currentOutput = 0.0f;

/* Sample counter for 12-second toggle */
volatile UInt32 sampleCounter = 0;
#define SAMPLES_PER_12SEC  (12 * 12500)  // 12 seconds * 12.5KHz = 150000

/* ============================= FIR Filter Coefficients ============================= */
/* 64 taps, Equiripple, BP 1.5-2.5KHz, Fs=12.5KHz */
const float firCoeffs[FIR_TAPS] = {
    0.0003506808716,  0.0005403755931, -0.0001476470788, -0.00151818723,  -0.001844612649,
   -1.632882777e-05,  0.002162050456,   0.001954977633,   0.0003062846081, 0.001174360164,
    0.00406578416,    0.00139504578,   -0.01044074818,   -0.01942235231,  -0.00797533989,
    0.02061888948,    0.03650538996,    0.01668436639,   -0.02093236707,  -0.0347879231,
   -0.01400227565,    0.005606766324,  -0.004901695997,  -0.01741161384,   0.01615281031,
    0.07799657434,    0.07962168008,   -0.02539804764,   -0.1497428715,   -0.1467341632,
    0.01220002957,    0.1778750569,     0.1778750569,     0.01220002957,  -0.1467341632,
   -0.1497428715,    -0.02539804764,    0.07962168008,    0.07799657434,   0.01615281031,
   -0.01741161384,   -0.004901695997,   0.005606766324,  -0.01400227565,  -0.0347879231,
   -0.02093236707,    0.01668436639,    0.03650538996,    0.02061888948,  -0.00797533989,
   -0.01942235231,   -0.01044074818,    0.00139504578,    0.00406578416,   0.001174360164,
    0.0003062846081,  0.001954977633,   0.002162050456,  -1.632882777e-05,-0.001844612649,
   -0.00151818723,   -0.0001476470788,  0.0005403755931,  0.0003506808716
};

/* FIR Delay line */
float firDelayLine[FIR_TAPS];

/* ============================= IIR Filter Coefficients ============================= */
/* 6th order Elliptic, BP 3.5-4.5KHz, Fs=12.5KHz, 3 Biquad Sections */
#define IIR_SECTIONS 3

const float SOS_NUM[IIR_SECTIONS][3] = {
    { 0.2003775239,  -0.2672816277,   0.2003775239 },
    { 0.2003775239,   0.3771858513,   0.2003775239 },
    { 0.2275227159,   0.0,           -0.2275227159 }
};

const float SOS_DEN[IIR_SECTIONS][3] = {
    { 1.0,   0.3663362563,   0.8769097924 },
    { 1.0,   1.202890992,    0.9015244246 },
    { 1.0,   0.779078424,    0.7722849846 }
};

/* IIR State variables */
float iirState[IIR_SECTIONS][2];

/* ============================= Helper Functions ============================= */

/* Generate Sawtooth voltage (0.1 to 1.0) */
float generateSawtooth(void)
{
    float sweepTime;
    float increment;

    sweepTime = (sweepTimeSelect == 0) ? (3.0f * FS) : (6.0f * FS);

    increment = (V_MAX - V_MIN) / sweepTime;

    sawtoothValue += increment;

    if (sawtoothValue >= V_MAX) {
        sawtoothValue = V_MIN;
    }

    return sawtoothValue;
}

/* Generate VCO signal: f = k * v */
float generateVCO(float voltage)
{
    float frequency;
    float phaseDelta;
    float output;

    frequency = K_VCO * voltage;

    phaseDelta = 2.0f * PI * frequency * TS;

    vcoPhase += phaseDelta;

    if (vcoPhase >= 2.0f * PI) {
        vcoPhase -= 2.0f * PI;
    }

    /* Generate sine output */
    output = sinf(vcoPhase);

    return output;
}

/* ============================= Filter Functions ============================= */

/* FIR Filter - Direct Form */
/* BP 1.5-2.5KHz - passes VCO frequencies when sawtooth is 0.3-0.5V */
float firFilter(float input)
{
    int i;
    float output = 0.0f;

    for (i = FIR_TAPS - 1; i > 0; i--) {
        firDelayLine[i] = firDelayLine[i-1];
    }
    firDelayLine[0] = input;

    for (i = 0; i < FIR_TAPS; i++) {
        output += firCoeffs[i] * firDelayLine[i];
    }

    return output;
}

/* IIR Filter - Direct Form II Transposed (3 Biquad Sections) */
/* BP 3.5-4.5KHz - passes VCO frequencies when sawtooth is 0.7-0.9V */
float iirFilter(float input)
{
    int i;
    float x, y;
    float w0;

    x = input;

    for (i = 0; i < IIR_SECTIONS; i++) {
        w0 = x - SOS_DEN[i][1] * iirState[i][0] - SOS_DEN[i][2] * iirState[i][1];
        y = SOS_NUM[i][0] * w0 + SOS_NUM[i][1] * iirState[i][0] + SOS_NUM[i][2] * iirState[i][1];

        iirState[i][1] = iirState[i][0];
        iirState[i][0] = w0;

        x = y;
    }

    return y;
}

/* ============================= Main ============================= */
Int main(Void)
{
    BIOS_start();
    return (0);
}

/* ============================= SWI - Sampling ============================= */
Void SwiSampling()
{

    float voltage;

    /* Count samples for 12-second toggle */
    sampleCounter++;
    if (sampleCounter >= SAMPLES_PER_12SEC) {
        sampleCounter = 0;

        /* Toggle filter: FIR <-> IIR */
        filterSelect = (filterSelect == 0) ? 1 : 0;

        /* Toggle sweep time: 3s <-> 6s */
        sweepTimeSelect = (sweepTimeSelect == 0) ? 1 : 0;

        /* Reset sawtooth */
        sawtoothValue = V_MIN;
    }

    /* Generate sawtooth 0.1-1V to sweep VCO frequency 500Hz-5000Hz */
    voltage = generateSawtooth();

    /* Generate VCO sine wave input */
    currentInput = generateVCO(voltage);

    /* Store for CCS Dual Time graph display (2000 samples buffer) */
    inputBuffer[bufferIndex] = currentInput;

    /* Make Task algorithm thread ready to run */
    Semaphore_post(sem_t);
}

/* ============================= Task - Algorithm ============================= */
/* Processing in Task allows longer computation than HWI/SWI */
Void taskAlgorithm()
{
    while (TRUE)
    {
        Semaphore_pend(sem_t, BIOS_WAIT_FOREVER);

        /* Apply selected filter */
        if (filterSelect == 0) {
            /* FIR Filter */
            currentOutput = firFilter(currentInput);
        } else {
            /* IIR Filter */
            currentOutput = iirFilter(currentInput);
        }

        outputBuffer[bufferIndex] = currentOutput;

        bufferIndex++;
        if (bufferIndex >= BUFFER_SIZE) {
            bufferIndex = 0;
        }
    }
}

/* ============================= HWI - Timer ============================= */
/* Timer runs at 12.5KHz (80us period) - only triggers sampling */
Void timerFunc()
{
    /* Make Swi thread ready to run */
    Swi_post(swi_sample);
}

/* ============================= CLOCK - 12 Second Toggle ============================= */
/* CLOCK Module disabled - using sampleCounter in SwiSampling instead */
Void clockFunc12Sec(UArg arg)
{
    /* Not used - toggle implemented via sample counting for reliable operation */
}
