/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-G16
 */

#ifndef xconfig_UIA_JTAGStopMode__
#define xconfig_UIA_JTAGStopMode__



#endif /* xconfig_UIA_JTAGStopMode__ */ 
