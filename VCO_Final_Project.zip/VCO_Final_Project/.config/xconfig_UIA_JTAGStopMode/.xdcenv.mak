#
_XDCBUILDCOUNT = 0
ifneq (,$(findstring path,$(_USEXDCENV_)))
override XDCPATH = C:/ti/uia_2_30_01_02/packages;C:/ti/bios_6_76_03_01/packages;C:/ti/ccs1100/ccs/bios_6_76_03_01/packages;C:/Users/user/workspace_v11/VCO_Final_Project/.config
override XDCROOT = C:/ti/xdctools_3_55_02_22_core
override XDCBUILDCFG = ./config.bld
endif
ifneq (,$(findstring args,$(_USEXDCENV_)))
override XDCARGS = 
override XDCTARGETS = 
endif
#
ifeq (0,1)
PKGPATH = C:/ti/uia_2_30_01_02/packages;C:/ti/bios_6_76_03_01/packages;C:/ti/ccs1100/ccs/bios_6_76_03_01/packages;C:/Users/user/workspace_v11/VCO_Final_Project/.config;C:/ti/xdctools_3_55_02_22_core/packages;..
HOSTOS = Windows
endif
