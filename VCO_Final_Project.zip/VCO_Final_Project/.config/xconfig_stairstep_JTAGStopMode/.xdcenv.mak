#
_XDCBUILDCOUNT = 
ifneq (,$(findstring path,$(_USEXDCENV_)))
override XDCPATH = C:/ti/ccs1100/ccs/uia_2_30_01_02/packages;C:/ti/ccs1100/ccs/bios_6_76_03_01/packages;C:/ti/workspace_2026_a/UIA_StopMode_Template/.config
override XDCROOT = C:/ti/ccs1100/ccs/xdctools_3_55_02_22_core
override XDCBUILDCFG = ./config.bld
endif
ifneq (,$(findstring args,$(_USEXDCENV_)))
override XDCARGS = 
override XDCTARGETS = 
endif
#
ifeq (0,1)
PKGPATH = C:/ti/ccs1100/ccs/uia_2_30_01_02/packages;C:/ti/ccs1100/ccs/bios_6_76_03_01/packages;C:/ti/workspace_2026_a/UIA_StopMode_Template/.config;C:/ti/ccs1100/ccs/xdctools_3_55_02_22_core/packages;..
HOSTOS = Windows
endif
