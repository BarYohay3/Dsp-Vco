# invoke SourceDir generated makefile for UIA_JTAGStopMode.pe674
UIA_JTAGStopMode.pe674: .libraries,UIA_JTAGStopMode.pe674
.libraries,UIA_JTAGStopMode.pe674: package/cfg/UIA_JTAGStopMode_pe674.xdl
	$(MAKE) -f C:\Users\user\workspace_v11\VCO_Final_Project/src/makefile.libs

clean::
	$(MAKE) -f C:\Users\user\workspace_v11\VCO_Final_Project/src/makefile.libs clean

